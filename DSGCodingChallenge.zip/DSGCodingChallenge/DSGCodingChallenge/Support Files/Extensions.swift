//
//  Extensions.swift
//  DSGCodingChallenge
//
//  Created by Sanketh on 05/30/21.
//  Copyright © 2021 Sanketh. All rights reserved.
//

import UIKit

extension String {
    func getFormattedDate() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        guard let date = formatter.date(from: self) else {
            return "Format Error"
        }
        
        formatter.dateFormat = "EEE, MMM d, yyyy HH:mm a"
        let newString = formatter.string(from: date)
        return newString
    }
}

extension UIView {
    func dropShadow() {
        layer.shadowRadius = 5.0
        layer.shadowColor = UIColor(red: 176/255, green: 199/255, blue: 226/255, alpha: 1.0).cgColor
        layer.shadowOffset  = CGSize(width: 0, height: 0)
        layer.shadowOpacity = 0.5;
        layer.masksToBounds = false;
        let shadowInsets = UIEdgeInsets(top: -1.5, left: -1.5, bottom: -1.0, right: -1.0)
        let shadowPath = UIBezierPath(rect: bounds.inset(by: shadowInsets))
        layer.shadowPath = shadowPath.cgPath
    }
}

extension UISearchBar {
    func setMagnifyingGlassColorTo(color: UIColor) {
        tintColor = UIColor.white
        if let textfield = self.value(forKey: "searchField") as? UITextField {
            textfield.backgroundColor = .black
            textfield.textColor = UIColor.white
            let glassIconView = textfield.leftView as? UIImageView
            glassIconView?.image = glassIconView?.image?.withRenderingMode(.alwaysTemplate)
            glassIconView?.tintColor = color
        }
    }
}
