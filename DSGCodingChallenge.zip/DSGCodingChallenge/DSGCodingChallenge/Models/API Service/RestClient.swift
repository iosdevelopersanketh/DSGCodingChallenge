
//
//  RestClient.swift
//  DSGCodingChallenge
//
//  Created by Sanketh on 05/31/21.
//  Copyright © 2021 Sanketh. All rights reserved.
//

import UIKit

enum HttpMethod: String {
    case POST
    case GET
    case PUT
    case DELETE
    case UPDATE
}

enum Environemnt: String {
    case prod
    case dev
    case stag
}

enum URLs {
    static func getBaseURL() -> String {
        switch environment {
        case .prod:
            return "https://api.seatgeek.com/2/"
        case .dev:
            return "dev";
        default:
            return "staging"
        }
    }
}

enum EndPoint: String {
    case events
    
    static func getEndPoint(query: EndPoint) -> String {
        switch query {
        case events:
            return "events" //client_id
        }
    }
}

let environment: Environemnt = .prod

class RestClient: NSObject {
    
    static let shared = RestClient()
    
    private override init() { }
    
    func fetchEvents(successHandler: @escaping (Events)->(), failureHanlder: @escaping (String)->()) {
        let baseURL = URLs.getBaseURL()
        let endPoint = EndPoint.getEndPoint(query: .events)
        let params = ["client_id": CLIENT_ID]
        processRequest(finalEndPoint: baseURL + endPoint, httpMethod: .GET, contentType: nil, params: params, headers: nil, body: nil, successHandler: {(response: Any) in
            
            guard let data = response as? Data else { return }
            do {
                let events = try JSONDecoder().decode(Events.self, from: data)
                successHandler(events)
            } catch {
                failureHanlder("Found unexpected results")
            }
        } ) {(errorMessage) in
                failureHanlder(errorMessage?.description ?? "")
        }
    }
}

extension RestClient {
    
    private func processRequest(finalEndPoint: String, httpMethod: HttpMethod, contentType: String?, params: [String: String]?, headers: [String: Any]?, body: [String: Any]?, successHandler: @escaping (Any)->(), failureHandler: @escaping (String?)->()) {
        
        if !NetworkManager.isConnectedToNetwork() {
            failureHandler("Please check your network connectivity and try again")
            return
        }
        
        guard var urlComponents = URLComponents(string: finalEndPoint) else { return }
        
        if let queryParams = params, queryParams.count > 0 {
            var queryItems:[NSURLQueryItem] = []
            
            let keys = queryParams.keys
            for key in keys {
                queryItems.append(NSURLQueryItem(name: key, value:queryParams[key]))
            }
            urlComponents.queryItems = queryItems as [URLQueryItem]
        }
        
        guard let url = urlComponents.url else {
            return
        }
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = httpMethod.rawValue
        if let body = body {
            let jsonData = try? JSONSerialization.data(withJSONObject: body)
            urlRequest.httpBody = jsonData
            print("Requst body: \(jsonData)")
            
            urlRequest.addValue(contentType ?? "application/json", forHTTPHeaderField: "Content-Type")
            urlRequest.addValue("application/json", forHTTPHeaderField: "Accept")
        }
        
        if let customHeaders = headers {
            for key in customHeaders.keys {
                if let customHeader = customHeaders[key] {
                    urlRequest.setValue(customHeader as? String, forHTTPHeaderField:key)
                }
            }
        }
                
        let urlSession = URLSession.shared
        
        let dataTask = urlSession.dataTask(with: urlRequest) { (data, response, error) in
            DispatchQueue.main.async {
                
                if error != nil {
                    failureHandler(error?.localizedDescription)
                    return
                }
                
                guard let data = data else {
                        failureHandler("Our services are down at this moment. Please try again later")
                        return }
                DispatchQueue.main.async {
                        let jsonData = try? JSONSerialization.jsonObject(with: data, options: .allowFragments)
                    successHandler(data)
                }
                    
                if let error = error {
                        print(error)
                        DispatchQueue.main.async {
                            failureHandler(error.localizedDescription)
                        }
                        return
                    }
                }
            }
        dataTask.resume()
    }
}
