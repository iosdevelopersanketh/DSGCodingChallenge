
//
//  EventsAPI.swift
//  DSGCodingChallenge
//
//  Created by Sanketh on 05/29/21.
//  Copyright © 2021 Sanketh. All rights reserved.
//

import Foundation

class EventsAPI {
    static let shared = EventsAPI()
    
    func fetchEvents(successHandler: @escaping ((Events)->()), failureHandler: @escaping ((String) -> ())) {
        RestClient.shared.fetchEvents(successHandler: { (events) in
            print(events)
            successHandler(events)
        }) { (error) in
            print(error)
            failureHandler(error)
        }
    }
}
