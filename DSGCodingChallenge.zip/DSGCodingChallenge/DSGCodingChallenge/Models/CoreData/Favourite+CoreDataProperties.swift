//
//  Favourite+CoreDataProperties.swift
//  DSGCodingChallenge
//
//  Created by Sanketh on 05/31/21.
//  Copyright © 2021 Sanketh. All rights reserved.
//
//

import Foundation
import CoreData


extension Favourite {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Favourite> {
        return NSFetchRequest<Favourite>(entityName: "Favourite")
    }

    @NSManaged public var eventId: Int64

}
