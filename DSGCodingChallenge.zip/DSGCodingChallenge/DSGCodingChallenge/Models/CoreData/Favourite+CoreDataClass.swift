//
//  Favourite+CoreDataClass.swift
//  DSGCodingChallenge
//
//  Created by Sanketh on 05/31/21.
//  Copyright © 2021 Sanketh. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Favourite)
public class Favourite: NSManagedObject {

}
