//
//  CoreDataManager.swift
//  GarmentCollection
//
//  Created by Sanketh on 13/08/20.
//  Copyright © 2020 Sanketh. All rights reserved.
//

import Foundation
import CoreData

public class CoreDataManager {
    static let shared = CoreDataManager()
    
    lazy var context = persistentContainer.viewContext
        
    lazy var persistentContainer: NSPersistentContainer = {
        
           let container = NSPersistentContainer(name: "DSGCodingChallenge")
           container.loadPersistentStores(completionHandler: { (storeDescription, error) in
               if let error = error as NSError? {
                   fatalError("Unresolved error \(error), \(error.userInfo)")
               }
           })
           return container
       }()
    
       func saveContext () {
           if context.hasChanges {
               do {
                   try context.save()
               } catch {
                   let nserror = error as NSError
                   fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
               }
           }
       }
    
    func handleFavourite(eventId: Int) {
        if isFavourite(eventId: eventId) {
            let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Favourite")
            fetchRequest.predicate = NSPredicate(format: "eventId == %d", eventId)
            do {
                if let favouriteEventId = try context.fetch(fetchRequest).first {                 
                    context.delete(favouriteEventId)
                }
            } catch {
                // TODO
            }
        } else {
            let newID = Favourite(context: context)
            newID.eventId = Int64(eventId)
            saveContext()
        }
    }
    
    func isFavourite(eventId: Int) -> Bool {
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Favourite")
        fetchRequest.predicate = NSPredicate(format: "eventId == %d", eventId)
        fetchRequest.fetchLimit =  1
        do {
            let count = try context.count(for: fetchRequest)
            if count > 0 {
                return true
            }else {
                return false
            }
        } catch {
            return false
        }
        
    }
    
//    func saveGarment(name: String) {
//        let newGarment = Garment(context: context)
//        newGarment.name = name
//        newGarment.createdOn = Date()
//        saveContext()
//    }
//    
//    func getGarments(sortBy: SortOrder) -> [Garment] {
//        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: Garment.description())
//        
//        if sortBy == .date {
//            let sort = NSSortDescriptor(key: #keyPath(Garment.createdOn), ascending: true)
//            fetchRequest.sortDescriptors = [sort]
//        } else {
//            let sort = NSSortDescriptor(key: #keyPath(Garment.name), ascending: true)
//            fetchRequest.sortDescriptors = [sort]
//        }
//    
//        do {
//            if let garments = try context.fetch(fetchRequest) as? [Garment] {
//                print(garments)
//                return garments
//            }
//        } catch {
//            print("Error while fetching the Garments")
//            return []
//        }
//        return []
//    }
//    
//    func reset() {
//        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: Garment.description())
//        let batchDelete = NSBatchDeleteRequest(fetchRequest: fetchRequest)
//        try? context.execute(batchDelete)
//    }
}
