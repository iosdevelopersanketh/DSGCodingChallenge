//
//  Event.swift
//  DSGCodingChallenge
//
//  Created by Sanketh on 05/31/21.
//  Copyright © 2021 Sanketh. All rights reserved.
//

import Foundation

// MARK: - Events

struct Events: Codable {
    let events: [Event]
    let meta: Meta
}

struct Meta: Codable {
    let geolocation: String?
    let page: Int?
    let per_page: Int?
    let took: Int?
    let total: Int?
}

// MARK: - Event
struct Event: Codable {
    let type: String?
    let id: Int?
    let datetimeUTC: String?
    let venue: Venue?
    let datetimeTbd: Bool?
    let performers: [Performer]?
    let isOpen: Bool?
    let links: [String]?
    let datetimeLocal: String?
    let timeTbd: Bool?
    let shortTitle, visibleUntilUTC: String?
    let stats: EventStats?
    let url: String?
    let score: Double?
    let taxonomies: [Taxonomy]?
    let announceDate, createdAt: String?
    let dateTbd: Bool?
    let title: String
    let popularity: Double?
    let eventDescription, status: String?
    let accessMethod: AccessMethod?
    let eventPromotion: String?
    let announcements: Announcements?
    let conditional: Bool?
    let enddatetimeUTC: String?
    let themes, domainInformation: [String]?

    enum CodingKeys: String, CodingKey {
        case type, id
        case datetimeUTC = "datetime_utc"
        case venue
        case datetimeTbd = "datetime_tbd"
        case performers
        case isOpen = "is_open"
        case links
        case datetimeLocal = "datetime_local"
        case timeTbd = "time_tbd"
        case shortTitle = "short_title"
        case visibleUntilUTC = "visible_until_utc"
        case stats, url, score
        case taxonomies
        case announceDate = "announce_date"
        case createdAt = "created_at"
        case dateTbd = "date_tbd"
        case title, popularity
        case eventDescription = "description"
        case status
        case accessMethod = "access_method"
        case eventPromotion = "event_promotion"
        case announcements = "announcements"
        case conditional
        case enddatetimeUTC = "enddatetime_utc"
        case themes
        case domainInformation = "domain_information"
    }
}

// MARK: - Announcements
struct Announcements: Codable {
    let checkoutDisclosures: CheckoutDisclosures?

    enum CodingKeys: String, CodingKey {
        case checkoutDisclosures = "checkout_disclosures"
    }
}

// MARK: - CheckoutDisclosures
struct CheckoutDisclosures: Codable {
    let messages: [Message]?
}

// MARK: - Message
struct Message: Codable {
    let text: String?
}

// MARK: - Performer
struct Performer: Codable {
    let type, name: String?
    let image: String?
    let id: Int?
    let images: Images?
    let divisions: [Division]?
    let hasUpcomingEvents, primary: Bool?
    let stats: PerformerStats?
    let taxonomies: [Taxonomy]?
    let imageAttribution: String?
    let url: String?
    let score: Double?
    let slug: String?
    let homeVenueID: Int?
    let shortName: String?
    let numUpcomingEvents: Int?
    let colors, imageLicense: String?
    let popularity: Int?
    let location: Location?

    enum CodingKeys: String, CodingKey {
        case type, name, image, id, images, divisions
        case hasUpcomingEvents = "has_upcoming_events"
        case primary, stats, taxonomies
        case imageAttribution = "image_attribution"
        case url, score, slug
        case homeVenueID = "home_venue_id"
        case shortName = "short_name"
        case numUpcomingEvents = "num_upcoming_events"
        case colors
        case imageLicense = "image_license"
        case popularity, location
    }
}

// MARK: - Images
struct Images: Codable {
    let huge: String?
}

// MARK: - PerformerStats
struct PerformerStats: Codable {
    let eventCount: Int?

    enum CodingKeys: String, CodingKey {
        case eventCount = "event_count"
    }
}

// MARK: - Taxonomy
struct Taxonomy: Codable {
    let id: Int?
    let name: String?
    let parentID: Int?
    let documentSource: DocumentSource?
    let rank: Int?

    enum CodingKeys: String, CodingKey {
        case id, name
        case parentID = "parent_id"
        case documentSource = "document_source"
        case rank
    }
}

// MARK: - DocumentSource
struct DocumentSource: Codable {
    let sourceType, generationType: String?

    enum CodingKeys: String, CodingKey {
        case sourceType = "source_type"
        case generationType = "generation_type"
    }
}

// MARK: - EventStats
struct EventStats: Codable {
    let listingCount: Int?
    let averagePrice, lowestPriceGoodDeals, lowestPrice: Int?
    let highestPrice, visibleListingCount, medianPrice: Int?
//    let lowestSgBasePrice, lowestSgBasePriceGoodDeals: String?

    enum CodingKeys: String, CodingKey {
        case listingCount = "listing_count"
        case averagePrice = "average_price"
        case lowestPriceGoodDeals = "lowest_price_good_deals"
        case lowestPrice = "lowest_price"
        case highestPrice = "highest_price"
        case visibleListingCount = "visible_listing_count"
        case medianPrice = "median_price"
//        case lowestSgBasePrice = "lowest_sg_base_price"
//        case lowestSgBasePriceGoodDeals = "lowest_sg_base_price_good_deals"
    }
}

// MARK: - Venue
struct Venue: Codable {
    let state, nameV2, postalCode, name: String?
    let links: [String]?
    let timezone: String?
    let url: String?
    let score: Double?
    let location: Location?
    let address, country: String?
    let hasUpcomingEvents: Bool?
    let numUpcomingEvents: Int?
    let city, slug, extendedAddress: String?
    let id, popularity: Int?
    let accessMethod: AccessMethod?
    let metroCode, capacity: Int?
    let displayLocation: String?

    enum CodingKeys: String, CodingKey {
        case state
        case nameV2 = "name_v2"
        case postalCode = "postal_code"
        case name, links, timezone, url, score, location, address, country
        case hasUpcomingEvents = "has_upcoming_events"
        case numUpcomingEvents = "num_upcoming_events"
        case city, slug
        case extendedAddress = "extended_address"
        case id, popularity
        case accessMethod = "access_method"
        case metroCode = "metro_code"
        case capacity
        case displayLocation = "display_location"
    }
}

// MARK: - Location
struct Location: Codable {
    let lat, lon: Double?
}

//MARK: - AccessMethod

struct AccessMethod: Codable {
    let created_at: String?
    let employee_only: Bool?
    let method: String?
}

// MARK: - Division
struct Division: Codable {
    let taxonomyID: Int
    let shortName: String?
    let displayName, displayType: String
    let divisionLevel: Int
    let slug: String?

    enum CodingKeys: String, CodingKey {
        case taxonomyID = "taxonomy_id"
        case shortName = "short_name"
        case displayName = "display_name"
        case displayType = "display_type"
        case divisionLevel = "division_level"
        case slug
    }
}
