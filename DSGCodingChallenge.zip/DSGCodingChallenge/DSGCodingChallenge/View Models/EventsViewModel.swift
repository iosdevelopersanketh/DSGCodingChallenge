//
//  EventsViewModel.swift
//  DSGCodingChallenge
//
//  Created by Sanketh on 05/31/21.
//  Copyright © 2021 Sanketh. All rights reserved.
//

import Foundation

class EventsViewModel {
    var allEvents: [Event] = []
    var binding: ((String?)->()) = {_ in }
    
    var filteredEvents: [Event] = [] {
        didSet {
            binding(nil)
        }
    }
        
    @objc
    func fetchEvents(isRefresh: Bool = false) {
        ProgressHUD.show("Fetching...")
        EventsAPI.shared.fetchEvents(successHandler: { [weak self] (events) in
            self?.allEvents = events.events
            self?.filteredEvents = events.events
            ProgressHUD.dismiss()
        }) { [weak self] (error) in
            self?.binding(error)
            ProgressHUD.showFailed(error, interaction: false)
        }
    }
    
    func filterEvents(searchText: String) {
        filteredEvents = allEvents.filter({ (anEvent) -> Bool in
            anEvent.title.lowercased().contains(searchText.lowercased())
        })
        if searchText.trimmingCharacters(in: .whitespaces).isEmpty {
            filteredEvents = allEvents
        }
    }
}
