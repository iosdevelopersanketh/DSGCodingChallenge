//
//  ViewController.swift
//  DSGCodingChallenge
//
//  Created by Sanketh on 29/05/21.
//  Copyright © 2021 Sanketh. All rights reserved.
//

import UIKit

enum SegueIdentifiers: String {
    case EventDetailViewController
}

class EventsListViewController: UIViewController {
    private var selectedEvent: Event?
    private var viewModel = EventsViewModel()
    @IBOutlet weak var noResultsLabel: UILabel!
    @IBOutlet weak var eventsListView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action:
                     #selector(handleRefresh),
                                 for: .valueChanged)
        refreshControl.tintColor = UIColor.red
        return refreshControl
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        customizeUI()
        viewModel.binding = { [weak self] (error) in
            self?.noResultsLabel.isHidden =  self?.viewModel.filteredEvents.count != 0
            self?.eventsListView.reloadData()
            self?.refreshControl.endRefreshing()
        }
        viewModel.fetchEvents()
        eventsListView.refreshControl = refreshControl
    }
    
    @objc
    func handleRefresh() {        
        viewModel.fetchEvents(isRefresh: true)
    }
    
    func customizeUI() {
        eventsListView.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 40))
        navigationItem.titleView = searchBar
        navigationController?.navigationBar.barStyle = .black
        let textAttributes = [NSAttributedString.Key.foregroundColor:UIColor.white]
        navigationController?.navigationBar.titleTextAttributes = textAttributes        
        searchBar.setMagnifyingGlassColorTo(color: .white)
        self.title = ""
    }
    
    func refreshEventsListView() {
        eventsListView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        refreshEventsListView()
    }
}

extension EventsListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.filteredEvents.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let eventCell = tableView.dequeueReusableCell(withIdentifier: EventTableViewCell.cellIdentifier) as? EventTableViewCell else {
            fatalError("No cell found with the identifier EventTableViewCell")
            return UITableViewCell()
        }
        let currentEvent = viewModel.filteredEvents[indexPath.row]
        eventCell.setupCell(event: currentEvent, indexPath: indexPath)
        if let imagePath = currentEvent.performers?.first?.image {
            ImageLoader.shared.obtainImageWithPath(imagePath: imagePath) { (image) in
                if let updateCell = tableView.cellForRow(at: indexPath) as? EventTableViewCell {
                    updateCell.thumbnail.image = image
                }
            }
        }
        
        return eventCell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedEvent = viewModel.filteredEvents[indexPath.row]
        performSegue(withIdentifier: SegueIdentifiers.EventDetailViewController.rawValue, sender: nil)
    }
}

extension EventsListViewController {
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destinationViewController = segue.destination as? EventDetailViewController {            
            destinationViewController.event = selectedEvent
        }
    }
}

extension EventsListViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        viewModel.filterEvents(searchText: searchText)
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
    }
}
