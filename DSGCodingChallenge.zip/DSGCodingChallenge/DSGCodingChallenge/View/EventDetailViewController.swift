//
//  EventDetailViewController.swift
//  DSGCodingChallenge
//
//  Created by Sanketh on 05/29/21.
//  Copyright © 2021 Sanketh. All rights reserved.
//

import UIKit

class EventDetailViewController: UIViewController {
    var event: Event?
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var eventPicImageView: UIImageView!
    @IBOutlet weak var eventAddressLabel: UILabel!
    @IBOutlet weak var eventDateLabel: UILabel!
    @IBOutlet weak var favouriteIcon: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        populateUI()
    }
    
    func populateUI() {
        navigationController?.navigationBar.prefersLargeTitles = false
        titleLabel.text = event?.title
        eventAddressLabel.text = event?.venue?.displayLocation
        eventDateLabel.text = event?.datetimeUTC?.getFormattedDate()
        favouriteIcon.isSelected = CoreDataManager.shared.isFavourite(eventId: event!.id!)
        if let imagePath = event?.performers?.first?.image {
            ImageLoader.shared.obtainImageWithPath(imagePath: imagePath) { [weak self] (image) in
                self?.eventPicImageView.image = image
            }
        }
        self.navigationItem.backBarButtonItem?.title = ""
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
    
    @IBAction func toggleFavourite(sender: UIButton) {
        sender.isSelected = !sender.isSelected
        CoreDataManager.shared.handleFavourite(eventId: event!.id!)
    }
}
