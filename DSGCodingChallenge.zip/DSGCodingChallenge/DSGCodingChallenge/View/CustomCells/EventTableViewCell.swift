//
//  EventTableViewCell.swift
//  DSGCodingChallenge
//
//  Created by Sanketh on 05/31/21.
//  Copyright © 2021 Sanketh. All rights reserved.
//

import UIKit

class EventTableViewCell: UITableViewCell {
    static let cellIdentifier = "EventTableViewCell"
    
    @IBOutlet weak var thumbnail: UIImageView!
    @IBOutlet weak var favouriteIcon: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var contentHolder: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        thumbnail.layer.cornerRadius = 5.0
        thumbnail.clipsToBounds = true
        contentHolder.layer.cornerRadius = 5.0
        contentHolder.clipsToBounds = true
        contentHolder.dropShadow()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setupCell(event: Event, indexPath: IndexPath) {
        titleLabel.text = event.title
        addressLabel.text = event.venue?.displayLocation
        dateLabel.text = event.datetimeUTC?.getFormattedDate()
        favouriteIcon.isHidden = !CoreDataManager.shared.isFavourite(eventId: event.id!)
    }
}
